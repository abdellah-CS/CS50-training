#include <stdio.h>
#include <cs50.h>
#include <time.h>
int main(void)
{
    int h,m,s;
    scanf("%i %i %i",&h,&m,&s);
    printf("%i %i %i", h,m,s);
    while(1){
        s+=1;
        if(s>59)
        {
            m+=1;
            s=0;
            if(m>59){
                m=0;
                h+=1;
            }
        }
        
    }
}    