#include <stdio.h>
#include <cs50.h>
int get_length(string v);
int main (void)
{
    string sentence = get_string("text : ");
    int length = get_length(sentence);
    printf("\n");
}
int get_length(string v)
{
    int i = 0;
    while(v[i] != '\0')
    {
        i += 1 ;
    }
    printf("the alphabet number is:  %i ", i);
    return i;
}