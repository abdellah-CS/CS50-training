#include <stdio.h>
#include <cs50.h>
int main(void)
{
    char w1 = 'H';
    char w2 = 'I';
    char w3 = '!';
    printf( "%c%c %c ",w1,w2,w3 );
    printf("\n");
}
